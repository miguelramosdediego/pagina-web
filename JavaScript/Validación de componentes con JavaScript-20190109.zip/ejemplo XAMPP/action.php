<?php
	$examen = $_POST['examen'];
	$trabajo = $_POST['trabajo'];
	$media = $_POST['media'];
?>

Esto es lo que has enviado desde el formulario<br><br>
Nota examen: <?php echo $examen; ?><br>
Nota trabajo: <?php echo $trabajo; ?><br>
Nota media: <?php echo $media; ?><br>